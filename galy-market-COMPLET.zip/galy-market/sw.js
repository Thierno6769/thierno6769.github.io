const CACHE_NAME = 'galy-market-boutique-v1';

const CACHE_FILES = [
  './',
  './index.html',
  './catalogue.html',
  './produit.html',
  './panier.html',
  './commande.html',
  './account.html',
  './contact.html',
  './wishlist.html',
  './404.html',
  './css/style.css',
  './css/catalogue.css',
  './css/produit.css',
  './css/commande.css',
  './css/account.css',
  './css/contact.css',
  './css/wishlist.css',
  './css/footer.css',
  './css/animations.css',
  './js/main.js',
  './js/products.js',
  './js/catalogue.js',
  './js/produit.js',
  './js/commande.js',
  './js/account.js',
  './js/contact.js',
  './js/wishlist.js',
  './js/footer.js',
  './js/animations.js',
  './manifest.json',
  './icons/icon-192x192.png',
  './icons/icon-512x512.png',
  './icons/apple-touch-icon.png',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache =>
      Promise.allSettled(CACHE_FILES.map(url => cache.add(url).catch(() => {})))
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  if (event.request.url.startsWith('chrome-extension://')) return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      const network = fetch(event.request).then(res => {
        if (res && res.status === 200) {
          caches.open(CACHE_NAME).then(c => c.put(event.request, res.clone()));
        }
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
