/* ═══════════════════════════════════════════
   GALY MARKET — admin.js
   Étape 5 : Panneau d'administration
═══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  const $ = id => document.getElementById(id);
  const fmt = n => n.toLocaleString('fr-FR') + ' GNF';

  /* ══════════════════════
     AUTH
  ══════════════════════ */
  const ADMIN_USER = 'admin';
  const ADMIN_PASS = 'admin2025';
  const AUTH_KEY   = 'GM_ADMIN_AUTH';

  function checkAuth() {
    return localStorage.getItem(AUTH_KEY) === '1';
  }
  function login() {
    const u = $('loginUser')?.value.trim();
    const p = $('loginPass')?.value.trim();
    if (u === ADMIN_USER && p === ADMIN_PASS) {
      localStorage.setItem(AUTH_KEY, '1');
      $('adminLogin').style.display = 'none';
      $('adminPanel').style.display = 'flex';
      renderAll();
    } else {
      const err = $('loginErr');
      if (err) { err.textContent = '❌ Identifiants incorrects.'; }
    }
  }

  if (checkAuth()) {
    $('adminLogin').style.display = 'none';
    $('adminPanel').style.display = 'flex';
    renderAll();
  }

  $('loginBtn')?.addEventListener('click', login);
  $('loginUser')?.addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
  $('loginPass')?.addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
  $('lfeye')?.addEventListener('click', () => {
    const inp = $('loginPass');
    const ic  = $('lfeye').querySelector('i');
    if (!inp) return;
    inp.type = inp.type === 'password' ? 'text' : 'password';
    ic.className = inp.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
  });
  $('admLogout')?.addEventListener('click', () => {
    localStorage.removeItem(AUTH_KEY);
    location.reload();
  });

  /* ══════════════════════
     DATA
  ══════════════════════ */
  function getOrders()  { return JSON.parse(localStorage.getItem('GM_ORDERS') || '[]'); }
  function saveOrders(o){ localStorage.setItem('GM_ORDERS', JSON.stringify(o)); }

  // Produits : GM_PRODUCTS est dans products.js + overrides locaux
  function getProds() {
    const overrides = JSON.parse(localStorage.getItem('GM_PROD_OVERRIDES') || '{}');
    return GM_PRODUCTS.map(p => ({ ...p, ...(overrides[p.id] || {}) }));
  }
  function saveProdOverride(p) {
    const ov = JSON.parse(localStorage.getItem('GM_PROD_OVERRIDES') || '{}');
    ov[p.id] = p; localStorage.setItem('GM_PROD_OVERRIDES', JSON.stringify(ov));
  }

  // Coupons
  const DEFAULT_COUPONS = {
    'GALY10':    { type:'percent',  value:10,    label:'10% de réduction',       active:true },
    'GALY20':    { type:'percent',  value:20,    label:'20% de réduction',       active:true },
    'BIENVENUE': { type:'percent',  value:15,    label:'15% — Bienvenue !',      active:true },
    'PROMO50K':  { type:'fixed',    value:50000, label:'50 000 GNF offerts',     active:true },
    'LIVRAISON': { type:'delivery', value:0,     label:'Livraison offerte',      active:true },
  };
  function getCoupons() {
    return JSON.parse(localStorage.getItem('GM_ADMIN_COUPONS') || JSON.stringify(DEFAULT_COUPONS));
  }

  // Zones
  const DEFAULT_ZONES = [
    { id:'conakry-centre',     name:'Conakry Centre',     price:0,      delay:'24h'      },
    { id:'conakry-periph',     name:'Conakry Périphérie', price:50000,  delay:'24-48h'   },
    { id:'basse-guinee',       name:'Basse Guinée',       price:100000, delay:'2-3 jours'},
    { id:'haute-guinee',       name:'Haute Guinée',       price:150000, delay:'3-5 jours'},
    { id:'guinee-forestiere',  name:'Guinée Forestière',  price:150000, delay:'3-5 jours'},
    { id:'moyenne-guinee',     name:'Moyenne Guinée',     price:150000, delay:'3-5 jours'},
  ];

  /* ══════════════════════
     NAVIGATION TABS
  ══════════════════════ */
  document.querySelectorAll('.adm-link[data-tab]').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      switchTab(link.dataset.tab);
    });
  });

  window.switchTab = function(tab) {
    document.querySelectorAll('.adm-link').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    const link = document.querySelector(`.adm-link[data-tab="${tab}"]`);
    if (link) link.classList.add('active');
    $(`tab-${tab}`)?.classList.add('active');
    const titles = { dashboard:'Dashboard', commandes:'Commandes', produits:'Produits', coupons:'Coupons', clients:'Clients', livraison:'Livraison', reglages:'Réglages' };
    if ($('tabTitle')) $('tabTitle').textContent = titles[tab] || tab;
    // Render on switch
    if (tab === 'commandes') renderCommandes();
    if (tab === 'produits')  renderProduits();
    if (tab === 'coupons')   renderCoupons();
    if (tab === 'clients')   renderClients();
    if (tab === 'livraison') renderLivraison();
  };

  /* ══════════════════════
     RENDER ALL
  ══════════════════════ */
  window.renderAll = function() {
    renderDashboard();
    renderCommandes();
    renderProduits();
    renderCoupons();
    renderClients();
    renderLivraison();
  };

  /* ══════════════════════
     DASHBOARD
  ══════════════════════ */
  function renderDashboard() {
    // Date
    const now = new Date();
    if ($('admDate')) $('admDate').textContent = now.toLocaleDateString('fr-FR', { weekday:'long', year:'numeric', month:'long', day:'numeric' });

    const orders = getOrders();
    const ca     = orders.reduce((a, o) => a + (o.total || 0), 0);
    const clients = [...new Set(orders.map(o => o.client?.tel))].length;

    if ($('kpiCA'))      $('kpiCA').textContent      = fmt(ca);
    if ($('kpiOrders'))  $('kpiOrders').textContent  = orders.length;
    if ($('kpiClients')) $('kpiClients').textContent = clients;
    if ($('nbCommandes'))$('nbCommandes').textContent= orders.filter(o => !o.status || o.status === 'nouvelle').length || '';

    // Dernières commandes
    const dc = $('dashOrders');
    if (dc) {
      if (!orders.length) {
        dc.innerHTML = '<div style="padding:20px;text-align:center;color:var(--adm-muted);font-size:13px">Aucune commande pour l\'instant</div>';
      } else {
        dc.innerHTML = orders.slice(0,5).map(o => `
          <div class="dash-order-row">
            <span class="dor-ref">${o.ref}</span>
            <span class="dor-client">${o.client?.prenom} ${o.client?.nom}</span>
            <span class="dor-total">${fmt(o.total)}</span>
            <span class="dor-status">${statusPill(o.status || 'nouvelle')}</span>
          </div>`).join('');
      }
    }

    // Top produits
    const tp = $('dashTopProds');
    if (tp) {
      const prods = getProds().slice(0, 5);
      tp.innerHTML = prods.map(p => `
        <div class="dash-prod-row">
          <span class="dpr-em">${p.em}</span>
          <span class="dpr-name">${p.name}</span>
          <span class="dpr-price">${fmt(p.price)}</span>
        </div>`).join('');
    }

    // Charts
    drawCharts(orders);
  }

  /* ══════════════════════
     CHARTS (Canvas)
  ══════════════════════ */
  function drawCharts(orders) {
    drawSalesChart(orders);
    drawCatChart();
  }

  function drawSalesChart(orders) {
    const canvas = $('salesChart'); if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const days = 7;
    const labels = [];
    const data   = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      labels.push(d.toLocaleDateString('fr-FR', { weekday:'short', day:'numeric' }));
      const dayOrders = orders.filter(o => {
        const od = new Date(o.date);
        return od.toDateString() === d.toDateString();
      });
      data.push(dayOrders.reduce((a, o) => a + (o.total || 0), 0));
    }

    // Simple canvas bar chart
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const W = canvas.offsetWidth || 600, H = 180;
    canvas.width = W; canvas.height = H;
    const max = Math.max(...data, 1);
    const barW = (W / days) * 0.55;
    const gap  = (W / days) * 0.45;

    data.forEach((val, i) => {
      const x = i * (W / days) + gap / 2;
      const barH = (val / max) * (H - 44);
      const y = H - barH - 30;

      // Bar gradient
      const grad = ctx.createLinearGradient(0, y, 0, H - 30);
      grad.addColorStop(0, '#f68b1e');
      grad.addColorStop(1, 'rgba(246,139,30,.2)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect(x, y, barW, barH, 4);
      ctx.fill();

      // Label day
      ctx.fillStyle = '#8a7a6a';
      ctx.font = '11px DM Sans, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(labels[i], x + barW / 2, H - 8);

      // Value
      if (val > 0) {
        ctx.fillStyle = '#1a1206';
        ctx.font = 'bold 10px DM Sans, sans-serif';
        ctx.fillText(val >= 1000000 ? (val/1000000).toFixed(1)+'M' : val >= 1000 ? (val/1000).toFixed(0)+'K' : val, x + barW / 2, y - 4);
      }
    });
  }

  function drawCatChart() {
    const canvas = $('catChart'); if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const prods = getProds();
    const cats = {};
    prods.forEach(p => { cats[p.cat] = (cats[p.cat] || 0) + 1; });
    const labels = Object.keys(cats).map(c => (GM_CATS?.[c]?.label || c).split(' ')[0]);
    const data   = Object.values(cats);
    const colors = ['#f68b1e','#27ae60','#3498db','#9b59b6','#e74c3c','#f1c40f'];

    const W = canvas.offsetWidth || 280, H = 200;
    canvas.width = W; canvas.height = H;
    const cx = W / 2, cy = H / 2 - 10, R = Math.min(cx, cy) - 20;
    const total = data.reduce((a,b) => a+b, 0);
    let start = -Math.PI / 2;

    data.forEach((val, i) => {
      const slice = (val / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, R, start, start + slice);
      ctx.closePath();
      ctx.fillStyle = colors[i % colors.length];
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Label
      const midAngle = start + slice / 2;
      const lx = cx + Math.cos(midAngle) * (R * 0.65);
      const ly = cy + Math.sin(midAngle) * (R * 0.65);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 11px DM Sans, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(val, lx, ly + 4);

      start += slice;
    });

    // Legend
    ctx.font = '11px DM Sans, sans-serif';
    labels.forEach((lb, i) => {
      const lx = (i % 3) * (W / 3) + 10;
      const ly = H - 28 + Math.floor(i / 3) * 14;
      ctx.fillStyle = colors[i % colors.length];
      ctx.fillRect(lx, ly, 10, 10);
      ctx.fillStyle = '#8a7a6a';
      ctx.textAlign = 'left';
      ctx.fillText(lb, lx + 14, ly + 9);
    });
  }

  /* ══════════════════════
     COMMANDES
  ══════════════════════ */
  function renderCommandes(filter = '') {
    let orders = getOrders();
    if (filter) orders = orders.filter(o => (o.status || 'nouvelle') === filter);
    const tbody = $('ordersTbody'), empty = $('ordersEmpty');
    if (!tbody) return;
    if (!orders.length) {
      tbody.innerHTML = '';
      if (empty) empty.style.display = 'block';
      return;
    }
    if (empty) empty.style.display = 'none';
    tbody.innerHTML = orders.map((o, i) => `
      <tr>
        <td><strong style="color:var(--adm-gold)">${o.ref}</strong></td>
        <td><div>${o.client?.prenom} ${o.client?.nom}</div><div style="font-size:11px;color:var(--adm-muted)">${o.client?.tel}</div></td>
        <td>${o.items?.length || 0} article${(o.items?.length || 0) > 1 ? 's' : ''}</td>
        <td><strong style="font-family:'Cormorant Garamond',serif;font-size:15px">${fmt(o.total)}</strong></td>
        <td>${o.zone?.zone || '—'}</td>
        <td>${o.payment || '—'}</td>
        <td>${statusPill(o.status || 'nouvelle')}</td>
        <td style="font-size:12px;color:var(--adm-muted)">${new Date(o.date).toLocaleDateString('fr-FR')}</td>
        <td>
          <button class="tbl-btn" onclick="openOrderModal(${i})" title="Voir"><i class="fas fa-eye"></i></button>
          <button class="tbl-btn" onclick="whatsappOrder(${i})" title="WhatsApp"><i class="fab fa-whatsapp" style="color:#25d366"></i></button>
          <button class="tbl-btn danger" onclick="deleteOrder(${i})" title="Supprimer"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`).join('');
  }

  $('filterStatus')?.addEventListener('change', e => renderCommandes(e.target.value));
  $('exportOrders')?.addEventListener('click', exportOrders);

  window.deleteOrder = function(i) {
    if (!confirm('Supprimer cette commande ?')) return;
    const orders = getOrders(); orders.splice(i, 1); saveOrders(orders);
    renderCommandes(); renderDashboard();
    showToastAdm('🗑️ Commande supprimée');
  };

  window.whatsappOrder = function(i) {
    const o = getOrders()[i]; if (!o) return;
    const items = o.items.map(it => `• ${it.name} ×${it.qty} = ${fmt(it.price*it.qty)}`).join('\n');
    const msg = `*Commande Galy Market*\nRéf: ${o.ref}\nClient: ${o.client?.prenom} ${o.client?.nom}\nTél: ${o.client?.tel}\nAdresse: ${o.adresse?.adresse}, ${o.adresse?.ville}\n\nArticles:\n${items}\n\nTotal: ${fmt(o.total)}`;
    window.open(`https://wa.me/224620000000?text=${encodeURIComponent(msg)}`, '_blank');
  };

  function exportOrders() {
    const orders = getOrders();
    if (!orders.length) { showToastAdm('⚠️ Aucune commande à exporter'); return; }
    const rows = [['Réf','Prénom','Nom','Téléphone','Ville','Adresse','Zone','Paiement','Statut','Total','Date']];
    orders.forEach(o => rows.push([
      o.ref, o.client?.prenom, o.client?.nom, o.client?.tel,
      o.adresse?.ville, o.adresse?.adresse, o.zone?.zone,
      o.payment, o.status || 'nouvelle', o.total,
      new Date(o.date).toLocaleDateString('fr-FR'),
    ]));
    const csv = rows.map(r => r.map(v => `"${v||''}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,\uFEFF' + encodeURIComponent(csv);
    a.download = `galy-market-commandes-${Date.now()}.csv`;
    a.click(); showToastAdm('📥 Export CSV téléchargé');
  }

  /* ── MODAL COMMANDE ── */
  window.openOrderModal = function(i) {
    const o = getOrders()[i]; if (!o) return;
    if ($('orderModalRef')) $('orderModalRef').textContent = o.ref;
    const body = $('orderModalBody'); if (!body) return;

    const PAY_LABELS = { orange:'Orange Money', mtn:'MTN Money', wave:'Wave', cash:'À la livraison', whatsapp:'Via WhatsApp' };
    body.innerHTML = `
      <div class="order-detail-grid">
        <div class="od-card">
          <h5>Client</h5>
          <div class="od-row"><span>Nom</span><strong>${o.client?.prenom} ${o.client?.nom}</strong></div>
          <div class="od-row"><span>Téléphone</span><strong>${o.client?.tel}</strong></div>
          <div class="od-row"><span>Email</span><strong>${o.client?.email || '—'}</strong></div>
        </div>
        <div class="od-card">
          <h5>Livraison</h5>
          <div class="od-row"><span>Ville</span><strong>${o.adresse?.ville}</strong></div>
          <div class="od-row"><span>Adresse</span><strong>${o.adresse?.adresse}</strong></div>
          <div class="od-row"><span>Zone</span><strong>${o.zone?.zone}</strong></div>
          <div class="od-row"><span>Délai</span><strong>${o.zone?.delay}</strong></div>
        </div>
        <div class="od-card">
          <h5>Paiement</h5>
          <div class="od-row"><span>Mode</span><strong>${PAY_LABELS[o.payment] || o.payment}</strong></div>
          <div class="od-row"><span>Coupon</span><strong>${o.coupon || 'Aucun'}</strong></div>
          <div class="od-row"><span>Remise</span><strong style="color:var(--adm-green)">${o.discount > 0 ? '− '+fmt(o.discount) : '—'}</strong></div>
        </div>
        <div class="od-card">
          <h5>Résumé</h5>
          <div class="od-row"><span>Sous-total</span><strong>${fmt(o.subtotal)}</strong></div>
          <div class="od-row"><span>Livraison</span><strong>${o.delivery === 0 ? 'Gratuit' : fmt(o.delivery)}</strong></div>
          <div class="od-row"><span>Date</span><strong>${new Date(o.date).toLocaleString('fr-FR')}</strong></div>
        </div>
      </div>
      <div class="od-items">
        <h5>Articles commandés</h5>
        ${(o.items || []).map(it => `
          <div class="od-item">
            <span class="od-item-em">${it.em || '📦'}</span>
            <span class="od-item-name">${it.name}</span>
            <span class="od-item-qty">× ${it.qty}</span>
            <span class="od-item-price">${fmt(it.price * it.qty)}</span>
          </div>`).join('')}
        <div class="od-total"><span>Total TTC</span><strong>${fmt(o.total)}</strong></div>
      </div>
      ${o.note ? `<div style="margin-top:16px;padding:14px;background:#fffbf5;border-radius:10px;border:1px solid var(--adm-border)"><strong style="font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:var(--adm-muted)">Note vendeur :</strong><p style="margin-top:6px;font-size:13px">${o.note}</p></div>` : ''}`;

    const statusSel = $('orderStatusSelect');
    if (statusSel) {
      statusSel.innerHTML = ['nouvelle','confirmee','en-cours','livree','annulee'].map(s =>
        `<option value="${s}" ${(o.status||'nouvelle') === s ? 'selected' : ''}>${s.replace('-',' ').replace(/^\w/, c => c.toUpperCase())}</option>`
      ).join('');
    }

    $('saveOrderStatus')?.addEventListener('click', () => {
      const orders = getOrders();
      orders[i].status = statusSel.value;
      saveOrders(orders); closeOrderModal();
      renderCommandes(); renderDashboard();
      showToastAdm('✅ Statut mis à jour');
    }, { once: true });

    $('orderModal')?.classList.add('open');
    $('admOverlay')?.classList.add('open');
  };
  window.closeOrderModal = function() {
    $('orderModal')?.classList.remove('open');
    $('admOverlay')?.classList.remove('open');
  };

  /* ══════════════════════
     PRODUITS
  ══════════════════════ */
  function renderProduits(search = '', cat = '') {
    let prods = getProds();
    if (search) prods = prods.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
    if (cat)    prods = prods.filter(p => p.cat === cat);
    const tbody = $('prodsTbody'); if (!tbody) return;
    const catMap = (typeof GM_CATS !== 'undefined') ? GM_CATS : {};
    tbody.innerHTML = prods.map(p => {
      const disc = p.old ? Math.round((1-p.price/p.old)*100) : 0;
      return `<tr>
        <td>
          <div class="prod-info">
            <span class="prod-em">${p.em}</span>
            <div><div class="prod-name">${p.name}</div><div class="prod-brand">${p.brand || '—'}</div></div>
          </div>
        </td>
        <td>${catMap[p.cat]?.label || p.cat}</td>
        <td><strong style="color:var(--adm-gold);font-family:'Cormorant Garamond',serif;font-size:15px">${fmt(p.price)}</strong></td>
        <td>${p.old ? `<span style="text-decoration:line-through;color:var(--adm-muted)">${fmt(p.old)}</span> <span style="color:var(--adm-red);font-size:11px;font-weight:800">-${disc}%</span>` : '—'}</td>
        <td><span style="font-weight:700;color:${p.stock <= 5 ? 'var(--adm-red)' : p.stock <= 15 ? '#f59e0b' : 'var(--adm-green)'}">${p.stock}</span></td>
        <td>⭐ ${p.rating}</td>
        <td>${p.flash ? '<span style="color:var(--adm-gold);font-weight:800">⚡ Oui</span>' : '<span style="color:var(--adm-muted)">—</span>'}</td>
        <td>
          <button class="tbl-btn" onclick="editProd(${p.id})" title="Modifier"><i class="fas fa-pen"></i></button>
          <a href="produit.html?id=${p.id}" target="_blank" class="tbl-btn" title="Voir"><i class="fas fa-eye"></i></a>
        </td>
      </tr>`;
    }).join('');
  }

  $('prodSearch')?.addEventListener('input',  e => renderProduits(e.target.value, $('prodCatFilter')?.value));
  $('prodCatFilter')?.addEventListener('change', e => renderProduits($('prodSearch')?.value, e.target.value));
  $('btnAddProd')?.addEventListener('click', () => openProdModal());

  window.editProd = function(id) {
    const p = getProds().find(x => x.id === id); if (!p) return;
    if ($('prodModalTitle')) $('prodModalTitle').textContent = 'Modifier le produit';
    if ($('pmId'))    $('pmId').value    = p.id;
    if ($('pmName'))  $('pmName').value  = p.name;
    if ($('pmCat'))   $('pmCat').value   = p.cat;
    if ($('pmBrand')) $('pmBrand').value = p.brand || '';
    if ($('pmPrice')) $('pmPrice').value = p.price;
    if ($('pmOld'))   $('pmOld').value   = p.old || '';
    if ($('pmStock')) $('pmStock').value = p.stock;
    if ($('pmEm'))    $('pmEm').value    = p.em;
    if ($('pmRating'))$('pmRating').value= p.rating;
    if ($('pmDesc'))  $('pmDesc').value  = p.desc || '';
    if ($('pmFlash')) $('pmFlash').checked = !!p.flash;
    if ($('pmNew'))   $('pmNew').checked  = !!p.isNew;
    $('prodModal')?.classList.add('open');
    $('admOverlay')?.classList.add('open');
  };

  function openProdModal() {
    if ($('prodModalTitle')) $('prodModalTitle').textContent = 'Ajouter un produit';
    ['pmId','pmName','pmBrand','pmPrice','pmOld','pmStock','pmEm','pmRating','pmDesc'].forEach(id => { const el = $(id); if (el) el.value = ''; });
    if ($('pmCat'))   $('pmCat').value = 'phones';
    if ($('pmFlash')) $('pmFlash').checked = false;
    if ($('pmNew'))   $('pmNew').checked   = false;
    $('prodModal')?.classList.add('open');
    $('admOverlay')?.classList.add('open');
  }

  window.closeProdModal = function() {
    $('prodModal')?.classList.remove('open');
    $('admOverlay')?.classList.remove('open');
  };

  $('saveProdBtn')?.addEventListener('click', () => {
    const id    = parseInt($('pmId')?.value) || Date.now();
    const name  = $('pmName')?.value.trim();
    if (!name) { showToastAdm('⚠️ Le nom est requis'); return; }
    const prod = {
      id, name, cat: $('pmCat')?.value,
      brand: $('pmBrand')?.value.trim(),
      price: parseInt($('pmPrice')?.value) || 0,
      old:   parseInt($('pmOld')?.value)   || null,
      stock: parseInt($('pmStock')?.value) || 0,
      em:    $('pmEm')?.value || '📦',
      rating:parseFloat($('pmRating')?.value) || 4.5,
      reviews: 0, desc: $('pmDesc')?.value.trim(),
      flash: $('pmFlash')?.checked || false,
      isNew: $('pmNew')?.checked   || false,
      img: '',
    };
    saveProdOverride(prod);
    closeProdModal(); renderProduits(); showToastAdm('✅ Produit sauvegardé');
  });

  /* ══════════════════════
     COUPONS
  ══════════════════════ */
  function renderCoupons() {
    const coupons = getCoupons();
    const grid = $('couponsGrid'); if (!grid) return;
    const TYPE_LABELS = { percent:'% réduction', fixed:'Montant fixe', delivery:'Livraison offerte' };
    grid.innerHTML = Object.entries(coupons).map(([code, c]) => `
      <div class="coupon-adm-card">
        <div class="cac-code">${code}</div>
        <div class="cac-label">${c.label}</div>
        <div class="cac-type">${TYPE_LABELS[c.type] || c.type} ${c.value ? '· Valeur : '+c.value+(c.type==='percent'?'%':' GNF') : ''}</div>
        <span class="cac-badge cac-active">✓ Actif</span>
      </div>`).join('');
  }

  $('btnAddCoupon')?.addEventListener('click', () => {
    const code = prompt('Code promo (ex: SUMMER25) :')?.toUpperCase().trim();
    if (!code) return;
    const val = prompt('Valeur (%) ou montant fixe (GNF) :');
    if (!val) return;
    const coupons = getCoupons();
    const isPercent = parseInt(val) <= 100;
    coupons[code] = { type: isPercent ? 'percent' : 'fixed', value: parseInt(val), label: `${val}${isPercent?'%':' GNF'} de réduction`, active: true };
    localStorage.setItem('GM_ADMIN_COUPONS', JSON.stringify(coupons));
    renderCoupons(); showToastAdm(`✅ Coupon ${code} créé`);
  });

  /* ══════════════════════
     CLIENTS
  ══════════════════════ */
  function renderClients() {
    const orders = getOrders();
    const clientMap = {};
    orders.forEach(o => {
      const key = o.client?.tel;
      if (!key) return;
      if (!clientMap[key]) clientMap[key] = { ...o.client, orders: 0, total: 0, last: o.date };
      clientMap[key].orders++;
      clientMap[key].total += o.total || 0;
      if (new Date(o.date) > new Date(clientMap[key].last)) clientMap[key].last = o.date;
    });
    const clients = Object.values(clientMap);
    const tbody = $('clientsTbody'), empty = $('clientsEmpty');
    if (!tbody) return;
    if (!clients.length) {
      tbody.innerHTML = '';
      if (empty) empty.style.display = 'block';
      return;
    }
    if (empty) empty.style.display = 'none';
    tbody.innerHTML = clients.sort((a,b) => b.total - a.total).map(c => `
      <tr>
        <td><strong>${c.prenom} ${c.nom}</strong></td>
        <td>${c.tel}</td>
        <td>—</td>
        <td>${c.orders}</td>
        <td><strong style="color:var(--adm-gold);font-family:'Cormorant Garamond',serif">${fmt(c.total)}</strong></td>
        <td style="font-size:12px;color:var(--adm-muted)">${new Date(c.last).toLocaleDateString('fr-FR')}</td>
      </tr>`).join('');
  }

  /* ══════════════════════
     LIVRAISON
  ══════════════════════ */
  function renderLivraison() {
    const grid = $('zonesAdmin'); if (!grid) return;
    grid.innerHTML = DEFAULT_ZONES.map(z => `
      <div class="zone-adm-card">
        <div class="zac-name">${z.name}</div>
        <div class="zac-field">
          <label>Prix (GNF)</label>
          <input type="number" value="${z.price}" id="zp-${z.id}" />
        </div>
        <div class="zac-field">
          <label>Délai estimé</label>
          <input type="text" value="${z.delay}" id="zd-${z.id}" />
        </div>
        <button class="btn-adm-primary" style="width:100%;justify-content:center;margin-top:4px" onclick="saveZone('${z.id}')">
          <i class="fas fa-floppy-disk"></i> Sauvegarder
        </button>
      </div>`).join('');
  }

  window.saveZone = function(id) {
    showToastAdm('✅ Zone mise à jour');
  };

  /* ══════════════════════
     STATUS PILL
  ══════════════════════ */
  function statusPill(status) {
    const map = { nouvelle:'sp-nouvelle', confirmee:'sp-confirmee', 'en-cours':'sp-en-cours', livree:'sp-livree', annulee:'sp-annulee' };
    const labels = { nouvelle:'Nouvelle', confirmee:'Confirmée', 'en-cours':'En cours', livree:'Livrée', annulee:'Annulée' };
    return `<span class="status-pill ${map[status]||'sp-nouvelle'}">${labels[status]||status}</span>`;
  }

  /* ══════════════════════
     TOAST
  ══════════════════════ */
  window.showToastAdm = function(msg) {
    const t = $('admToast'); if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 3000);
  };

  /* ══════════════════════
     BURGER & OVERLAY
  ══════════════════════ */
  $('admBurger')?.addEventListener('click', () => {
    $('admSidebar')?.classList.add('open');
    $('admOverlay')?.classList.add('open');
  });
  $('admSidebarClose')?.addEventListener('click', closeAdmSidebar);
  $('admOverlay')?.addEventListener('click', () => {
    closeAdmSidebar();
    closeOrderModal();
    closeProdModal();
  });
  function closeAdmSidebar() {
    $('admSidebar')?.classList.remove('open');
    if (!$('orderModal')?.classList.contains('open') && !$('prodModal')?.classList.contains('open'))
      $('admOverlay')?.classList.remove('open');
  }

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeOrderModal(); closeProdModal(); closeAdmSidebar(); }
  });

  /* ══════════════════════
     RECHERCHE GLOBALE
  ══════════════════════ */
  $('admSearch')?.addEventListener('input', e => {
    const q = e.target.value.toLowerCase();
    if (!q) return;
    // Basculer vers produits et filtrer
    switchTab('produits');
    renderProduits(q);
    const pi = $('prodSearch'); if (pi) pi.value = q;
  });

  /* ══════════════════════
     INIT
  ══════════════════════ */
  if (checkAuth()) {
    // Déjà appelé plus haut dans renderAll()
  }
});
