/* ═══════════════════════════════════════════
   GALY MARKET — main.js
   Étape 1 : Header + Nav + Hero
═══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* ── LOADER ── */
  const loader = document.getElementById('loader');
  if (loader) {
    setTimeout(() => loader.classList.add('hidden'), 2600);
  }

  /* ── HEADER SCROLL ── */
  const header = document.getElementById('header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 50);
    }, { passive: true });
  }

  /* ── BURGER / MENU MOBILE ── */
  const burger        = document.getElementById('burger');
  const mobileMenu    = document.getElementById('mobileMenu');
  const mobileOverlay = document.getElementById('mobileOverlay');
  const mobileClose   = document.getElementById('mobileClose');

  function openMenu() {
    burger?.classList.add('open');
    mobileMenu?.classList.add('open');
    mobileOverlay?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    burger?.classList.remove('open');
    mobileMenu?.classList.remove('open');
    mobileOverlay?.classList.remove('open');
    document.body.style.overflow = '';
  }

  burger?.addEventListener('click', openMenu);
  mobileClose?.addEventListener('click', closeMenu);
  mobileOverlay?.addEventListener('click', closeMenu);

  /* ── HERO SLIDER ── */
  const slides   = document.querySelectorAll('.slide');
  const dots     = document.querySelectorAll('.hero-dot');
  const prevBtn  = document.getElementById('heroPrev');
  const nextBtn  = document.getElementById('heroNext');
  let current    = 0;
  let autoTimer  = null;

  function goTo(index) {
    slides[current].classList.remove('active');
    dots[current]?.classList.remove('active');
    current = (index + slides.length) % slides.length;
    slides[current].classList.add('active');
    dots[current]?.classList.add('active');
  }

  function startAuto() {
    clearInterval(autoTimer);
    autoTimer = setInterval(() => goTo(current + 1), 5000);
  }

  prevBtn?.addEventListener('click', () => { goTo(current - 1); startAuto(); });
  nextBtn?.addEventListener('click', () => { goTo(current + 1); startAuto(); });
  dots.forEach(dot => {
    dot.addEventListener('click', () => { goTo(+dot.dataset.i); startAuto(); });
  });

  // Swipe mobile
  let touchStartX = 0;
  const heroEl = document.querySelector('.hero');
  heroEl?.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
  heroEl?.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) { goTo(diff > 0 ? current + 1 : current - 1); startAuto(); }
  }, { passive: true });

  startAuto();

  /* ── COUNTDOWN FLASH ── */
  const cdH = document.getElementById('cdH');
  const cdM = document.getElementById('cdM');
  const cdS = document.getElementById('cdS');

  function startCountdown() {
    // Heure de fin : aujourd'hui à minuit
    const now = new Date();
    const end = new Date(now);
    end.setHours(23, 59, 59, 0);
    let remaining = Math.floor((end - now) / 1000);

    const tick = () => {
      if (remaining <= 0) { remaining = 86399; } // repart à minuit
      const h = Math.floor(remaining / 3600);
      const m = Math.floor((remaining % 3600) / 60);
      const s = remaining % 60;
      if (cdH) cdH.textContent = String(h).padStart(2, '0');
      if (cdM) cdM.textContent = String(m).padStart(2, '0');
      if (cdS) cdS.textContent = String(s).padStart(2, '0');
      remaining--;
    };
    tick();
    setInterval(tick, 1000);
  }
  startCountdown();

  /* ── CART / WISHLIST BADGES ── */
  function updateBadges() {
    const cart     = JSON.parse(localStorage.getItem('GM_CART')     || '[]');
    const wishlist = JSON.parse(localStorage.getItem('GM_WISHLIST') || '[]');
    const qty      = cart.reduce((a, i) => a + i.qty, 0);

    const cartBadge = document.getElementById('cartBadge');
    const wishBadge = document.getElementById('wishBadge');
    if (cartBadge) cartBadge.textContent = qty > 0 ? qty : '';
    if (wishBadge) wishBadge.textContent = wishlist.length > 0 ? wishlist.length : '';
  }
  updateBadges();
  window.addEventListener('storage', updateBadges);

  /* ── SEARCH ── */
  const searchInput = document.getElementById('searchInput');
  searchInput?.addEventListener('keydown', e => {
    if (e.key === 'Enter' && searchInput.value.trim()) {
      window.location.href = `catalogue.html?q=${encodeURIComponent(searchInput.value.trim())}`;
    }
  });

  /* ── KEYBOARD ESC ── */
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeMenu();
  });

});
