/* ═══════════════════════════════════════════
   GALY MARKET — commande.js
   Étape 4 : Panier + Commande
═══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  const $   = id => document.getElementById(id);
  const fmt = n  => n.toLocaleString('fr-FR') + ' GNF';
  const PAGE = window.location.pathname.includes('commande') ? 'commande' : 'panier';

  let cart     = JSON.parse(localStorage.getItem('GM_CART')    || '[]');
  let wishlist = JSON.parse(localStorage.getItem('GM_WISHLIST')|| '[]');
  let coupon   = JSON.parse(localStorage.getItem('GM_COUPON')  || 'null');
  let selectedZone = { zone: 'conakry-centre', price: 0, delay: '24h' };
  let selectedPay  = 'cash';

  const saveCart   = () => localStorage.setItem('GM_CART',   JSON.stringify(cart));
  const saveCoupon = () => localStorage.setItem('GM_COUPON', JSON.stringify(coupon));

  const COUPONS = {
    'GALY10':   { type: 'percent',  value: 10,    label: '10% de réduction' },
    'GALY20':   { type: 'percent',  value: 20,    label: '20% de réduction' },
    'BIENVENUE':{ type: 'percent',  value: 15,    label: '15% — Bienvenue !' },
    'PROMO50K': { type: 'fixed',    value: 50000, label: '50 000 GNF offerts' },
    'LIVRAISON':{ type: 'delivery', value: 0,     label: 'Livraison offerte' },
  };

  function getSubtotal() { return cart.reduce((a,i) => a + i.price * i.qty, 0); }
  function getDiscount(sub) {
    if (!coupon) return 0;
    const c = COUPONS[coupon]; if (!c) return 0;
    if (c.type === 'percent')  return Math.round(sub * c.value / 100);
    if (c.type === 'fixed')    return Math.min(c.value, sub);
    if (c.type === 'delivery') return selectedZone.price;
    return 0;
  }
  function getDelivery() {
    if (coupon && COUPONS[coupon]?.type === 'delivery') return 0;
    if (getSubtotal() >= 500000) return 0;
    return selectedZone.price;
  }
  function getTotal() {
    return Math.max(0, getSubtotal() - getDiscount(getSubtotal()) + getDelivery());
  }

  /* ──────────────────────────────
     PAGE PANIER
  ────────────────────────────── */
  if (PAGE === 'panier') {

    function renderPanier() {
      const items = $('cartItems'), empty = $('panierEmpty'), cb = $('couponBlock');
      if (!items) return;
      if (!cart.length) {
        items.innerHTML = '';
        if (empty) empty.style.display = 'block';
        if (cb) cb.style.display = 'none';
        renderSummaryP(); return;
      }
      if (empty) empty.style.display = 'none';
      if (cb) cb.style.display = 'block';
      const catMap = (typeof GM_CATS !== 'undefined') ? GM_CATS : {};
      items.innerHTML = cart.map(item => {
        const prod = (typeof GM_PRODUCTS !== 'undefined') ? GM_PRODUCTS.find(p => p.id === item.id) : null;
        const cat  = catMap[prod?.cat]?.label || '';
        const old  = prod?.old;
        const saving = old ? (old - item.price) * item.qty : 0;
        return `<div class="panier-item">
          <div class="pi-img">${item.img ? `<img src="${item.img}" onerror="this.style.display='none'">` : item.em}</div>
          <div class="pi-details">
            ${cat ? `<div class="pi-cat">${cat}</div>` : ''}
            <div class="pi-name"><a href="produit.html?id=${item.id}">${item.name}</a></div>
            <div class="pi-price-row">
              <span class="pi-price">${fmt(item.price)}</span>
              ${old ? `<span class="pi-old">${fmt(old)}</span>` : ''}
              ${saving > 0 ? `<span class="pi-saving">Éco. ${fmt(saving)}</span>` : ''}
            </div>
            <div class="pi-qty-ctrl">
              <button class="pi-qty-btn" onclick="pQty(${item.id},-1)"><i class="fas fa-minus"></i></button>
              <span class="pi-qty-val">${item.qty}</span>
              <button class="pi-qty-btn" onclick="pQty(${item.id},+1)"><i class="fas fa-plus"></i></button>
            </div>
          </div>
          <div class="pi-total-col">
            <div class="pi-total">${fmt(item.price * item.qty)}</div>
            <button class="pi-del-btn" onclick="pDel(${item.id})"><i class="fas fa-times"></i></button>
          </div>
        </div>`;
      }).join('');
      renderSummaryP();
    }

    function renderSummaryP() {
      const sub  = getSubtotal();
      const disc = getDiscount(sub);
      const del  = getDelivery();
      const total= getTotal();
      const qty  = cart.reduce((a,i) => a+i.qty, 0);

      if ($('bcCount'))    $('bcCount').textContent    = `${qty} article${qty>1?'s':''}`;
      if ($('cartBadge'))  $('cartBadge').textContent  = qty > 0 ? qty : '';
      if ($('wishBadge'))  $('wishBadge').textContent  = wishlist.length > 0 ? wishlist.length : '';
      if ($('sumSubtotal'))$('sumSubtotal').textContent= fmt(sub);
      const dr = $('discountRow');
      if (dr) dr.style.display = disc > 0 ? 'flex' : 'none';
      if ($('sumDiscount'))$('sumDiscount').textContent= `− ${fmt(disc)}`;
      if ($('sumDelivery'))$('sumDelivery').textContent= del === 0 ? 'Gratuit ✓' : fmt(del);

      // Économies barré
      const orig = (typeof GM_PRODUCTS !== 'undefined')
        ? cart.reduce((a,i)=>{ const p=GM_PRODUCTS.find(x=>x.id===i.id); return a+(p?.old||i.price)*i.qty; }, 0) : sub;
      const savRow = $('savingRow');
      if (savRow) savRow.style.display = (orig-sub) > 0 ? 'flex' : 'none';
      if ($('sumSaving')) $('sumSaving').textContent = `${fmt(orig-sub)} économisés`;
      if ($('sumTotal'))  $('sumTotal').textContent  = fmt(total);

      // Barre livraison gratuite
      const FREE = 500000;
      const fill = $('fdbFill'), txt = $('fdbText'), amt = $('fdbAmt');
      if (fill) {
        if (sub >= FREE) {
          if (txt) txt.innerHTML = '🎉 <strong>Livraison offerte</strong> pour cette commande !';
          fill.style.width = '100%';
        } else {
          if (amt) amt.textContent = fmt(FREE - sub);
          fill.style.width = `${Math.min(100, sub/FREE*100)}%`;
        }
      }

      const btn = $('btnCheckout');
      if (btn) { btn.style.opacity = cart.length ? '1' : '.4'; btn.style.pointerEvents = cart.length ? 'auto' : 'none'; }
    }

    window.pQty = (id, d) => {
      const it = cart.find(i => i.id === id); if (!it) return;
      it.qty += d;
      if (it.qty <= 0) cart = cart.filter(i => i.id !== id);
      saveCart(); renderPanier();
    };
    window.pDel = (id) => {
      cart = cart.filter(i => i.id !== id);
      saveCart(); renderPanier(); showToast('🗑️ Article retiré');
    };

    $('clearCart')?.addEventListener('click', () => {
      if (confirm('Vider tout le panier ?')) { cart = []; saveCart(); renderPanier(); showToast('🗑️ Panier vidé'); }
    });

    if (coupon && $('couponInput')) { $('couponInput').value = coupon; showCouponMsg(true); }
    $('applyCoupon')?.addEventListener('click', applyCoupon);
    $('couponInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') applyCoupon(); });

    renderPanier();
  }

  /* ──────────────────────────────
     PAGE COMMANDE
  ────────────────────────────── */
  if (PAGE === 'commande') {

    function renderMiniCart() {
      const mc = $('miniCart'); if (!mc) return;
      mc.innerHTML = cart.length
        ? cart.map(it => `<div class="mc-item">
            <div class="mc-img">${it.img ? `<img src="${it.img}" onerror="this.style.display='none'">` : it.em}</div>
            <div class="mc-info"><div class="mc-name">${it.name}</div><div class="mc-qty">× ${it.qty}</div></div>
            <div class="mc-price">${fmt(it.price * it.qty)}</div>
          </div>`).join('')
        : '<p style="text-align:center;color:var(--muted);font-size:13px;padding:12px 0">Panier vide</p>';
    }

    function renderSummaryCmd() {
      const sub  = getSubtotal();
      const disc = getDiscount(sub);
      const del  = getDelivery();
      const total= getTotal();
      const qty  = cart.reduce((a,i)=>a+i.qty,0);
      if ($('cartBadge'))  $('cartBadge').textContent  = qty > 0 ? qty : '';
      if ($('sumSubtotal'))$('sumSubtotal').textContent = fmt(sub);
      const dr = $('discountRow'); if (dr) dr.style.display = disc > 0 ? 'flex' : 'none';
      if ($('sumDiscount'))$('sumDiscount').textContent = `− ${fmt(disc)}`;
      if ($('sumDelivery'))$('sumDelivery').textContent = del === 0 ? 'Gratuit ✓' : fmt(del);
      if ($('sumTotal'))   $('sumTotal').textContent    = fmt(total);
    }

    function bindZoneCards() {
      document.querySelectorAll('.zone-card').forEach(card => {
        card.addEventListener('click', () => {
          // Retirer active uniquement dans la même grille
          card.closest('.zones-grid').querySelectorAll('.zone-card').forEach(c => c.classList.remove('active'));
          card.classList.add('active');
          selectedZone = { zone: card.dataset.zone, price: parseInt(card.dataset.price), delay: card.dataset.delay };
          renderSummaryCmd();
        });
      });
    }
    bindZoneCards();

    // Gestion sélection quartier / hors Conakry
    window.onQuartierChange = function(val) {
      const blocConakry = document.getElementById('blocConakry');
      const blocHors    = document.getElementById('blocHors');
      const pmCash      = document.getElementById('pmCash');
      const pmWhatsapp  = document.getElementById('pmWhatsapp');
      if (!blocConakry || !blocHors) return;

      if (val === 'hors-conakry') {
        // Afficher bloc hors Conakry
        blocConakry.style.display = 'none';
        blocHors.style.display    = '';

        // Zone par défaut : première carte hors Conakry
        selectedZone = { zone: 'conakry-periph', price: 25000, delay: '24-48h' };
        blocHors.querySelectorAll('.zone-card').forEach(c => c.classList.remove('active'));
        const firstCard = blocHors.querySelector('.zone-card');
        if (firstCard) firstCard.classList.add('active');

        // Masquer "Paiement à la livraison" + "WhatsApp", basculer sur Orange Money
        if (pmCash)     pmCash.style.display     = 'none';
        if (pmWhatsapp) pmWhatsapp.style.display  = 'none';
        if (selectedPay === 'cash' || selectedPay === 'whatsapp') {
          selectedPay = 'orange';
          document.querySelectorAll('.pm-card').forEach(c => c.classList.remove('active'));
          const pmOrange = document.querySelector('[data-pm="orange"]');
          if (pmOrange) {
            pmOrange.classList.add('active');
            const radio = pmOrange.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
          }
        }

      } else {
        // Retour Conakry
        blocConakry.style.display = '';
        blocHors.style.display    = 'none';
        selectedZone = { zone: 'conakry-centre', price: 0, delay: '24h' };
        blocConakry.querySelectorAll('.zone-card').forEach(c => c.classList.remove('active'));
        const firstCard = blocConakry.querySelector('.zone-card');
        if (firstCard) firstCard.classList.add('active');

        // Réafficher "Paiement à la livraison" + "WhatsApp" + resélectionner cash
        if (pmCash) {
          pmCash.style.display = '';
          selectedPay = 'cash';
          document.querySelectorAll('.pm-card').forEach(c => c.classList.remove('active'));
          pmCash.classList.add('active');
          const radio = pmCash.querySelector('input[type="radio"]');
          if (radio) radio.checked = true;
        }
        if (pmWhatsapp) pmWhatsapp.style.display = '';
      }
      renderSummaryCmd();
      bindZoneCards();
    };


    const orders = JSON.parse(localStorage.getItem('GM_ORDERS')||'[]');
    orders.unshift(order); localStorage.setItem('GM_ORDERS', JSON.stringify(orders));
    cart = []; saveCart(); coupon = null; saveCoupon();
    openModal(order);
  }

  function openModal(o) {
    const PAY = { orange:'Orange Money', mtn:'MTN Money', wave:'Wave', cash:'Paiement à la livraison', whatsapp:'Via WhatsApp' };
    if ($('cmName'))  $('cmName').textContent  = `${o.client.prenom} ${o.client.nom}`;
    if ($('cmRef'))   $('cmRef').textContent   = o.ref;
    if ($('cmDelay')) $('cmDelay').textContent = o.zone.delay + ' après confirmation';
    if ($('cmTel'))   $('cmTel').textContent   = o.client.tel;
    if ($('cmAddr'))  $('cmAddr').textContent  = `${o.adresse.adresse}, ${o.adresse.ville}`;
    if ($('cmPay'))   $('cmPay').textContent   = PAY[o.payment] || o.payment;
    if ($('cmTotal')) $('cmTotal').textContent = fmt(o.total);
    $('confirmModal')?.classList.add('open');
    $('cmWhatsapp')?.addEventListener('click', () => {
      const items = o.items.map(i=>`• ${i.name} ×${i.qty} = ${fmt(i.price*i.qty)}`).join('\n');
      const msg = `*Commande Galy Market*\n\nRéf: ${o.ref}\nClient: ${o.client.prenom} ${o.client.nom}\nTél: ${o.client.tel}\nAdresse: ${o.adresse.adresse}, ${o.adresse.ville}\nPaiement: ${PAY[o.payment]}\n\n*Articles:*\n${items}\n\n*Total: ${fmt(o.total)}*`;
      window.open(`https://wa.me/224620000000?text=${encodeURIComponent(msg)}`, '_blank');
    }, { once: true });
  }

  /* ── TOAST ── */
  function showToast(msg) {
    const t = $('toast'), m = $('toastMsg'); if (!t||!m) return;
    m.textContent = msg; t.classList.add('show');
    clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 3200);
  }

  /* ── HEADER & BURGER ── */
  window.addEventListener('scroll', () => { $('header')?.classList.toggle('scrolled', window.scrollY > 50); }, { passive: true });
  const burger=$('burger'), mMenu=$('mobileMenu'), mOv=$('mobileOverlay'), mClose=$('mobileClose');
  burger?.addEventListener('click', ()=>{ burger.classList.add('open'); mMenu?.classList.add('open'); mOv?.classList.add('open'); });
  [mClose,mOv].forEach(el=>el?.addEventListener('click',()=>{ burger?.classList.remove('open'); mMenu?.classList.remove('open'); mOv?.classList.remove('open'); }));
  document.addEventListener('keydown', e => { if (e.key==='Escape') $('confirmModal')?.classList.remove('open'); });
});
