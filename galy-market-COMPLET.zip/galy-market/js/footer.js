/* ═══════════════════════════════════════════
   GALY MARKET — footer.js
   Footer global + WA flottant — injecté sur toutes les pages
═══════════════════════════════════════════ */

(function () {

  const FOOTER_HTML = `
  <footer class="site-footer">
    <div class="footer-inner">
      <div class="footer-col brand-col">
        <div class="footer-logo">GALY<span>MARKET</span></div>
        <p class="footer-tagline">La boutique en ligne de référence en Guinée. Produits authentiques, livraison rapide.</p>
        <div class="footer-socials">
          <a href="https://www.facebook.com/share/1Aj2FUMmU1/" target="_blank" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/galy_market224" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
          <a href="https://www.tiktok.com/@idrissa224sow" target="_blank" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
          <a href="https://t.me/galymarket" target="_blank" aria-label="Telegram"><i class="fab fa-telegram"></i></a>
        </div>
      </div>
      <div class="footer-col">
        <h4>Boutique</h4>
        <ul>
          <li><a href="catalogue.html">Catalogue</a></li>
          <li><a href="catalogue.html?promo=1">⚡ Flash Sale</a></li>
          <li><a href="catalogue.html?cat=phones">📱 Téléphones</a></li>
          <li><a href="catalogue.html?cat=mode">👗 Mode</a></li>
          <li><a href="catalogue.html?cat=beaute">💄 Beauté</a></li>
          <li><a href="catalogue.html?cat=bijoux">💍 Bijoux</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Mon compte</h4>
        <ul>
          <li><a href="account.html"><i class="fas fa-right-to-bracket fa-fw"></i> Connexion</a></li>
          <li><a href="account.html?form=register"><i class="fas fa-user-plus fa-fw"></i> Créer un compte</a></li>
          <li><a href="panier.html"><i class="fas fa-bag-shopping fa-fw"></i> Mon panier</a></li>
          <li><a href="wishlist.html"><i class="fas fa-heart fa-fw"></i> Mes favoris</a></li>
          <li><a href="account.html#ptab-orders"><i class="fas fa-box fa-fw"></i> Mes commandes</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Aide &amp; Infos</h4>
        <ul>
          <li><a href="contact.html">Contact</a></li>
          <li><a href="contact.html#faq">FAQ</a></li>
          <li><a href="#">Livraison &amp; délais</a></li>
          <li><a href="#">Politique de retour</a></li>
          <li><a href="#">CGU</a></li>
          <li><a href="admin.html" style="opacity:.4;font-size:11px">Espace admin</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Newsletter</h4>
        <p class="footer-nl-desc">Recevez nos offres exclusives en avant-première.</p>
        <div class="footer-newsletter">
          <input type="tel" id="gm-footer-nl-tel" placeholder="620 00 00 00" autocomplete="off" />
          <button id="gm-footer-nl-btn" aria-label="S'abonner"><i class="fas fa-paper-plane"></i></button>
        </div>
        <p class="footer-nl-msg" id="gm-footer-nl-msg"></p>
        <div class="footer-payment">
          <span class="fp-label">Paiements acceptés</span>
          <div class="fp-icons">
            <span class="fp-icon om">OM</span>
            <span class="fp-icon mtn">MTN</span>
            <span class="fp-icon wave">Wave</span>
            <span class="fp-icon cash">Cash</span>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2025 Galy Market · Conakry, Guinée · Tous droits réservés</span>
      <span class="footer-made">Fait avec <i class="fas fa-heart" style="color:#f68b1e"></i> en Guinée 🇬🇳</span>
    </div>
  </footer>`;

  const WA_BTN = `
  <a href="https://wa.me/224620000000?text=Bonjour%20Galy%20Market%20!" target="_blank"
     class="wa-float" title="Contacter sur WhatsApp" aria-label="WhatsApp">
    <i class="fab fa-whatsapp"></i>
    <span class="wa-float-pulse"></span>
  </a>`;

  /* ── Injecter si pas déjà de footer ── */
  function injectFooter() {
    if (document.querySelector('.site-footer')) return; // déjà présent (contact, wishlist)
    if (document.querySelector('.admin-layout')) return; // pas sur l'admin
    document.body.insertAdjacentHTML('beforeend', FOOTER_HTML);
  }

  /* ── Injecter le bouton WA si pas déjà présent ── */
  function injectWA() {
    if (document.querySelector('.wa-float')) return;
    if (document.querySelector('.admin-layout')) return;
    document.body.insertAdjacentHTML('beforeend', WA_BTN);
  }

  /* ── Newsletter footer ── */
  function initNewsletter() {
    const btn = document.getElementById('gm-footer-nl-btn');
    const inp = document.getElementById('gm-footer-nl-tel');
    const msg = document.getElementById('gm-footer-nl-msg');
    if (!btn || !inp) return;

    btn.addEventListener('click', () => {
      const tel = inp.value.trim();
      if (!tel || tel.length < 8) {
        if (msg) { msg.textContent = '⚠️ Numéro invalide'; msg.style.color = '#e74c3c'; }
        return;
      }
      const subs = JSON.parse(localStorage.getItem('GM_NEWSLETTER') || '[]');
      if (subs.includes(tel)) {
        if (msg) { msg.textContent = '✅ Déjà inscrit !'; msg.style.color = '#22c55e'; }
        return;
      }
      subs.push(tel);
      localStorage.setItem('GM_NEWSLETTER', JSON.stringify(subs));
      if (msg) { msg.textContent = '✅ Inscription confirmée !'; msg.style.color = '#22c55e'; }
      inp.value = '';
      setTimeout(() => { if (msg) msg.textContent = ''; }, 5000);
    });

    inp.addEventListener('keydown', e => { if (e.key === 'Enter') btn.click(); });
  }

  /* ── INIT ── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { injectFooter(); injectWA(); initNewsletter(); });
  } else {
    injectFooter(); injectWA(); initNewsletter();
  }

})();
