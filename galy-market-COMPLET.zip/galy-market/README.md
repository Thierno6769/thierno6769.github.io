# 🛍️ Galy Market — Boutique E-commerce Guinée

> **La boutique en ligne de référence en Guinée** · Conakry · 🇬🇳

![Version](https://img.shields.io/badge/version-1.0.0-f68b1e?style=flat-square)
![Pages](https://img.shields.io/badge/pages-12-27ae60?style=flat-square)
![Devise](https://img.shields.io/badge/devise-GNF-3498db?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-lightgrey?style=flat-square)

---

## 📋 Table des matières

- [Aperçu](#aperçu)
- [Fonctionnalités](#fonctionnalités)
- [Structure du projet](#structure-du-projet)
- [Installation](#installation)
- [Pages & navigation](#pages--navigation)
- [Accès administrateur](#accès-administrateur)
- [localStorage — données](#localstorage--données)
- [Codes promo](#codes-promo)
- [Réseaux sociaux](#réseaux-sociaux)
- [Personnalisation](#personnalisation)
- [Technologies](#technologies)

---

## 🌟 Aperçu

**Galy Market** est une boutique e-commerce complète en HTML/CSS/JS pur, sans framework, prête à déployer sur GitHub Pages, Netlify ou tout hébergeur statique.

| Caractéristique | Détail |
|---|---|
| 🌍 Pays | Guinée (Conakry) |
| 💰 Devise | Franc Guinéen (GNF) |
| 🎨 Couleur principale | Orange `#f68b1e` |
| 🔤 Typographies | Cormorant Garamond · DM Sans · Bebas Neue |
| 📱 Responsive | Mobile, tablette, desktop |
| ⚡ Dépendances | Aucune (vanilla JS) |

---

## ✨ Fonctionnalités

### 🛒 Boutique
- ✅ Catalogue produits avec filtres (catégorie, prix, note, marque, disponibilité)
- ✅ 20 produits · 6 catégories (Téléphones, Mode, Beauté, Maison, Sport, Bijoux)
- ✅ Tri multi-critères (prix, note, popularité, nouveautés)
- ✅ Vue grille / liste
- ✅ Flash Sale avec comptdown en temps réel
- ✅ Recherche globale avec URL params `?q=`

### 📄 Fiches produit
- ✅ Galerie photo / emoji animé + zoom modal
- ✅ Sélection quantité, stock en temps réel
- ✅ Ajout au panier + wishlist + partage social
- ✅ Avis clients avec système de notation (localStorage)
- ✅ Produits similaires
- ✅ Commande directe WhatsApp

### 🛒 Panier & Commande
- ✅ Cart drawer slide-in
- ✅ Gestion quantités, suppression, vidage
- ✅ Barre progression livraison offerte (seuil 500 000 GNF)
- ✅ Codes promo (5 codes actifs)
- ✅ Formulaire commande 5 étapes
- ✅ 6 zones de livraison Guinée
- ✅ 4 modes de paiement (Orange Money, MTN, Wave, À la livraison)
- ✅ Référence commande unique `GM-XXXXX`
- ✅ Confirmation WhatsApp message pré-rempli

### 👤 Compte client
- ✅ Inscription (téléphone + mot de passe)
- ✅ Connexion avec "Se souvenir de moi"
- ✅ Mot de passe oublié avec OTP simulé
- ✅ Profil : commandes, informations, sécurité, favoris
- ✅ Indicateur de force du mot de passe

### ❤️ Wishlist
- ✅ Ajout / retrait de favoris sur toutes les pages
- ✅ Tout ajouter au panier en un clic
- ✅ Empty state avec suggestions

### 📞 Contact
- ✅ Formulaire avec sélection de sujet rapide
- ✅ Envoi WhatsApp message pré-rempli
- ✅ FAQ accordéon (5 questions)
- ✅ Carte Google Maps (Kaloum, Conakry)
- ✅ Liens sociaux réels

### 🔒 Administration
- ✅ Dashboard KPI + graphiques (canvas natif)
- ✅ Gestion commandes avec statuts
- ✅ Gestion produits (CRUD)
- ✅ Gestion coupons
- ✅ Tableau clients auto-généré
- ✅ Zones de livraison éditables
- ✅ Réglages boutique + zone de danger
- ✅ Export CSV commandes

### 🎬 Animations (style Jumia)
- ✅ Loader / splash screen animé
- ✅ Transitions fluides entre pages (rideau orange)
- ✅ Scroll reveal en cascade
- ✅ Ripple effect sur boutons
- ✅ Flying item (emoji vole vers le panier)
- ✅ Confettis à la confirmation de commande
- ✅ Notifications social proof
- ✅ Skeleton loading
- ✅ Tilt 3D sur cartes produits
- ✅ Barre de progression scroll

---

## 📁 Structure du projet

```
galy-market/
├── 📄 index.html          → Accueil (hero, catégories, flash sale)
├── 📄 catalogue.html      → Grille produits + filtres
├── 📄 produit.html        → Fiche produit détaillée
├── 📄 panier.html         → Panier
├── 📄 commande.html       → Tunnel de commande
├── 📄 account.html        → Login / Inscription / Profil
├── 📄 wishlist.html       → Liste de favoris
├── 📄 contact.html        → Contact + FAQ + Carte
├── 📄 admin.html          → Panneau administration
├── 📄 404.html            → Page d'erreur
├── 📄 nouveautes.html     → (redirection → catalogue)
├── 📄 marques.html        → (redirection → catalogue)
│
├── css/
│   ├── style.css          → Variables globales + header + nav
│   ├── catalogue.css      → Styles catalogue
│   ├── produit.css        → Styles fiche produit
│   ├── commande.css       → Styles panier + commande
│   ├── admin.css          → Styles admin
│   ├── account.css        → Styles compte client
│   ├── contact.css        → Styles contact
│   ├── wishlist.css       → Styles wishlist
│   ├── 404.css            → Styles page 404
│   ├── animations.css     → Toutes les animations
│   └── footer.css         → Footer global + WA flottant
│
└── js/
    ├── main.js            → Header scroll + burger menu
    ├── products.js        → Catalogue de 20 produits (GM_PRODUCTS)
    ├── catalogue.js       → Filtres + grille + cart drawer
    ├── produit.js         → Fiche produit + avis
    ├── commande.js        → Panier + formulaire commande
    ├── admin.js           → Panneau admin complet
    ├── account.js         → Auth + profil client
    ├── contact.js         → Formulaire contact + FAQ
    ├── wishlist.js        → Gestion favoris
    ├── animations.js      → Moteur d'animations (API publique)
    └── footer.js          → Footer global injecté automatiquement
```

---

## 🚀 Installation

### Option 1 — GitHub Pages (recommandé)

```bash
# 1. Cloner ou uploader les fichiers sur GitHub
git init
git add .
git commit -m "🚀 Lancement Galy Market v1.0"
git remote add origin https://github.com/TON_USER/galy-market.git
git push -u origin main

# 2. Dans Settings → Pages → Source: main branch
# ✅ URL : https://TON_USER.github.io/galy-market/
```

### Option 2 — Netlify (drag & drop)

1. Aller sur [netlify.com](https://netlify.com)
2. Glisser-déposer le dossier `galy-market/`
3. ✅ En ligne en 30 secondes

### Option 3 — Local (VS Code)

```bash
# Avec l'extension Live Server dans VS Code
# Clic droit sur index.html → "Open with Live Server"
```

> ⚠️ **Important** : Ouvrir les fichiers via un serveur HTTP (Live Server, etc.), pas en double-cliquant directement (`file://`) pour éviter les erreurs CORS.

---

## 🗺️ Pages & navigation

| Page | URL | Description |
|------|-----|-------------|
| Accueil | `index.html` | Hero slider, catégories, flash sale, trust bar |
| Catalogue | `catalogue.html` | Grille produits, filtres sidebar, tri |
| Produit | `produit.html?id=1` | Fiche détaillée (id de 1 à 20) |
| Panier | `panier.html` | Articles, coupons, résumé |
| Commande | `commande.html` | Formulaire 5 étapes |
| Mon compte | `account.html` | Login / Inscription / Profil |
| Favoris | `wishlist.html` | Liste wishlist |
| Contact | `contact.html` | Formulaire + FAQ + Carte |
| Admin | `admin.html` | Panneau administration |
| 404 | `404.html` | Page d'erreur (redirection auto 15s) |

---

## 🔐 Accès administrateur

| Champ | Valeur |
|-------|--------|
| URL | `admin.html` |
| Identifiant | `admin` |
| Mot de passe | `admin2025` |

> Modifiable dans `js/admin.js` ligne `ADMIN_CREDENTIALS`

---

## 💾 localStorage — données

| Clé | Contenu |
|-----|---------|
| `GM_CART` | Articles dans le panier `[{id, name, price, qty, em}]` |
| `GM_WISHLIST` | IDs produits favoris `[1, 3, 7]` |
| `GM_ORDERS` | Commandes passées |
| `GM_USERS` | Comptes clients inscrits |
| `GM_SESSION` | Session utilisateur connecté |
| `GM_REVIEWS_{id}` | Avis produit par ID |
| `GM_ADMIN_AUTH` | Session admin |
| `GM_PROD_OVERRIDES` | Modifications produits (admin) |
| `GM_ADMIN_COUPONS` | Codes promo ajoutés (admin) |
| `GM_NEWSLETTER` | Numéros inscrits newsletter |
| `GM_CONTACT_MSGS` | Messages formulaire contact |

---

## 🎟️ Codes promo

| Code | Réduction |
|------|-----------|
| `GALY10` | -10% |
| `GALY20` | -20% |
| `BIENVENUE` | -15% |
| `PROMO50K` | -50 000 GNF |
| `LIVRAISON` | Livraison offerte |

> Nouveaux codes ajoutables depuis `admin.html` → onglet Coupons

---

## 📱 Réseaux sociaux

| Réseau | URL |
|--------|-----|
| Facebook | https://www.facebook.com/share/1Aj2FUMmU1/ |
| Instagram | https://www.instagram.com/galy_market224 |
| TikTok | https://www.tiktok.com/@idrissa224sow |
| Telegram | https://t.me/galymarket |

---

## 🎨 Personnalisation

### Changer les couleurs (css/style.css)
```css
:root {
  --gold:    #f68b1e;   /* Couleur principale */
  --gold-d:  #d4780f;   /* Variante foncée */
  --dark:    #0f0c08;   /* Fond sombre */
  --cream:   #fdf8f0;   /* Fond clair */
}
```

### Modifier les produits (js/products.js)
```js
const GM_PRODUCTS = [
  {
    id: 1,
    name: "Nom du produit",
    price: 2500000,      // Prix en GNF
    old: 3000000,        // Ancien prix (optionnel)
    cat: "phones",       // Catégorie
    em: "📱",            // Emoji affiché
    img: "",             // URL image (optionnel)
    stock: 15,
    rating: 4.5,
    brand: "Apple",
    tags: ["new", "promo"],
    desc: "Description...",
    specs: { Écran: "6.1 pouces", RAM: "6 Go" }
  }
];
```

### Changer le numéro WhatsApp
Rechercher `224620000000` dans tous les fichiers et remplacer par votre numéro.

### Zones de livraison
Modifiables dans `admin.html` → onglet **Zones** ou directement dans `js/commande.js`.

---

## 🛠️ Technologies

| Technologie | Usage |
|-------------|-------|
| **HTML5** | Structure sémantique |
| **CSS3** | Variables custom, Grid, Flexbox, animations |
| **JavaScript ES6+** | Vanilla JS, localStorage, IntersectionObserver |
| **Font Awesome 6.5** | Icônes |
| **Google Fonts** | Cormorant Garamond · DM Sans · Bebas Neue |
| **Google Maps Embed** | Carte contact |

> Aucun framework JS, aucune dépendance npm. 100% statique.

---

## 📊 API animations publique

```js
// Disponible sur toutes les pages via animations.js
GalyAnimations.confetti(3000)         // Confettis (durée ms)
GalyAnimations.toast('Message !')     // Toast notification
GalyAnimations.flyToCart(el, '📱')   // Animation ajout panier
GalyAnimations.skeletons(el, 8)      // Skeleton loading
GalyAnimations.counter(el, 1234)     // Compteur animé
GalyAnimations.socialProof()         // Notif achat récent
```

---

## 📝 Changelog

### v1.0.0 — 2025
- 🎉 Lancement initial
- ✅ 10 pages complètes
- ✅ Système d'animations complet
- ✅ Panneau admin full-featured
- ✅ Système de comptes clients
- ✅ Intégration WhatsApp

---

## 📄 Licence

MIT — Libre d'utilisation, modification et distribution.

---

<div align="center">
  <strong>Galy Market</strong> · Conakry, Guinée 🇬🇳<br/>
  Fait avec ❤️ et ☕
</div>
